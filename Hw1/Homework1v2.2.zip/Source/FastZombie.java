/**
 *
 *
 */
public class FastZombie {

    public FastZombie(String name, Position position) { // DO NOT CHANGE PARAMETERS
        
    }

}
