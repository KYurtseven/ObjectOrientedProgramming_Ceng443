/**
 *
 *
 */
public enum ZombieState {
    WANDERING,
    FOLLOWING;
}
