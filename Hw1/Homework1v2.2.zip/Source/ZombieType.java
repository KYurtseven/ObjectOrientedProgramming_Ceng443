/**
 *
 *
 */
public enum ZombieType {
    SLOW,
    REGULAR,
    FAST;
}
