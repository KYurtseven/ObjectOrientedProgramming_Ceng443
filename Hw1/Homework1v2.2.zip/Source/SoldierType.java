/**
 *
 *
 */
public enum SoldierType {
    REGULAR,
    COMMANDO,
    SNIPER;
}
