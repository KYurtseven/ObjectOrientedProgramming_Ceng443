/**
 *
 *
 */
public class SlowZombie {

    public SlowZombie(String name, Position position) { // DO NOT CHANGE PARAMETERS
        
    }
}
