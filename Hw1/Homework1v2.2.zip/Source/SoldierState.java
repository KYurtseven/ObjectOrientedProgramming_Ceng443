/**
 *
 *
 */
public enum SoldierState {
    SEARCHING,
    AIMING,
    SHOOTING;
}
