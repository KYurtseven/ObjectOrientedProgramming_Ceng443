/**
 *
 *
 */
public class Commando{

    public Commando(String name, Position position) { // DO NOT CHANGE PARAMETERS
        
    }

}
