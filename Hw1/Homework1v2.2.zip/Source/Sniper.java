/**
 *
 *
 */
public class Sniper {

    public Sniper(String name, Position position) { // DO NOT CHANGE PARAMETERS
        
    }

}
