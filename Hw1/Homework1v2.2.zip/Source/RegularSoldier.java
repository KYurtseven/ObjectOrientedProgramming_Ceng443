/**
 *
 *
 */
public class RegularSoldier{

    public RegularSoldier(String name, Position position) { // DO NOT CHANGE PARAMETERS
        
    }

}
